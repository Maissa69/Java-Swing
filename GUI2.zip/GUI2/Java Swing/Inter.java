import javax.swing.*;

public class Inter {

public static void  main(String []args){

    JFrame frame = new JFrame(null, null); // creation de frame 
    frame.setSize(420, 420);  // dimension de frame 
    frame.setVisible(true); // rendre la frame visible 

}
}
