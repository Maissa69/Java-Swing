import java.awt.event.MouseAdapter;

public class Adapter extends MouseAdapter {
    Adapter(){

    }
}
