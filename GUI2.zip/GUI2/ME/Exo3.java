import javax.swing.*;
import java.awt.*;
public class Exo3 {
    public static void main(String[] args) {
        
        JFrame fenetre = new JFrame("Une fenetre ");
        fenetre.setLayout((LayoutManager) new BoxLayout());
    }
}
