package GUI;

import javax.swing.JFrame;

public class Label {

    //JLabel = a GUI display area for s string of text, an image, or both 
    JFrame frame = new JFrame();


    
}
