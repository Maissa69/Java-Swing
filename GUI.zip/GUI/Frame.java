package GUI;

public class Frame {
    public static void main(String[] args) {


        new MyFrame();





        /*
        //JFrame = a GUI Window to add components to

        //creat a frame
        JFrame frame = new JFrame(); 

        //sets the X-dimention, and Y-dimention of frame 
        frame.setSize(420, 420); 

        //sets title of frame
        frame.setTitle("JFrame title goes here"); 

        //Bay default is HIDE_ON_CLOSE
        //frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 

        //do not close
       //frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);  

       //exit out of application
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  

        // make frame visible
        frame.setVisible(true); 

        //prevent frame from being resized
        frame.setResizable(true);

        //create image icone
        ImageIcon image = new ImageIcon("GUI/Akatsuke.jpeg");

        //change icone of frame
        frame.setIconImage(image.getImage());
        
        //change color of background
        //frame.getContentPane().setBackground(Color.BLACK);
        frame.getContentPane().setBackground(new Color(0x023446));
         */

    }
    
}
